
from PySide6.QtWidgets import (
    QApplication, QWidget,
    QVBoxLayout, QPlainTextEdit,
    QPushButton, QLabel
)
import sys

app = QApplication(sys.argv)

ventana = QWidget()
layout = QVBoxLayout(ventana)

editor = QPlainTextEdit()
editor.setPlaceholderText("Escribe aquí...")

boton = QPushButton("Mostrar texto")
resultado = QLabel("")

def mostrar_texto():
    texto = editor.toPlainText()
    resultado.setText(texto)

boton.clicked.connect(mostrar_texto)

layout.addWidget(editor)
layout.addWidget(boton)
layout.addWidget(resultado)

ventana.show()
sys.exit(app.exec())
